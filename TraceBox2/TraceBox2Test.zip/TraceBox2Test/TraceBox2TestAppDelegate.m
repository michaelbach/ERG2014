//
//  TraceBox2TestAppDelegate.m
//  TraceBox2Test
//
//  Created by bach on 23.05.10.
//  Copyright 2010 Universitäts-Augenklinik. All rights reserved.
//

#import "TraceBox2TestAppDelegate.h"

@implementation TraceBox2TestAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {	NSLog(@"TraceBox2TestAppDelegate>applicationDidFinishLaunching");
	tb2_1 = [[TraceBox2 alloc] initWithFrame:NSMakeRect(10.0, 100.0, 100.0, 50.0) andSuperView: [window contentView]];
	[tb2_1 setLineWidth: 1.0];  [tb2_1 addTestTrace];
	
	tb2_2 = [[TraceBox2 alloc] initWithFrame:NSMakeRect(1.0, 500.0, 600.0, 100.0) andSuperView: [window contentView]];
	[tb2_2 setLineWidth: 1.5];  [tb2_2 addTestTrace];  [tb2_2 addTestTrace];
	
	tb2_3 = [[TraceBox2 alloc] initWithFrame:NSMakeRect(1.0, 300.0, 600.0, 100.0) andSuperView: [window contentView]];
	[tb2_3 setLineWidth: 1];
	for (NSUInteger i = 0; i<4; ++i)    [tb2_3 addTestTrace];
	
}


- (void)applicationWillTerminate: (NSNotification *) aNotification {	NSLog(@"TraceBox2TestAppDelegate>applicationWillTerminate");
}


- (BOOL)applicationShouldTerminateAfterLastWindowClosed: (NSApplication *) theApplication {
	return YES;
}

@end
