//
//  TraceBox2TestAppDelegate.h
//  TraceBox2Test
//
//  Created by bach on 23.05.10.
//  Copyright 2010 Universitäts-Augenklinik. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "TraceBox2.h"



@interface TraceBox2TestAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
	TraceBox2 *tb2_1, *tb2_2, *tb2_3;	
}

@property (assign) IBOutlet NSWindow *window;

@end
