//
//  main.m
//  TraceBox2Test
//
//  Created by bach on 23.05.10.
//  Copyright 2010 Universitäts-Augenklinik. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
